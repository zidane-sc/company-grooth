
<p>Nama: {{ $data['name'] }} </p>
<p>Phone: {{ $data['phone'] }}</p>
<p>Email: {{ $data['email'] }}</p>
<p>Message: {{ $data['message'] }}</p>
