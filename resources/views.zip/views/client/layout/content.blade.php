<div class="content-wrapper">
@yield('content')
</div>

