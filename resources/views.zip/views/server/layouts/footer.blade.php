<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        {{-- <b>Version</b> 3.1.0-rc --}}
    </div>
    <strong>Copyright &copy;{{ 2020 }} <a href="{{ url('home') }}">Grooth</a>.</strong> All rights reserved.
</footer>